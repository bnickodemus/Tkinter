This  is a basic blackjack program written in python. It should be compatible with python3 and it uses tkinter as a ui. 


